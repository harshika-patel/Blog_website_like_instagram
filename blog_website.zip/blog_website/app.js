const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const mongoose = require('mongoose');
// const Post = require('./models/post'); // Assuming you have a Post model

const app = express();

// Parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'ejs');

// Middleware to serve static files from the 'public' directory
app.use(express.static('public'));

// app.get('/', (req, res) => {
//     res.render(__dirname + '/public/home');
//   });

app.get('/home',async (req, res) => {
    try {
        const posts = await Post.find({});
        
        res.render(__dirname + '/public/home', { posts }); // Render the main.ejs file and pass posts data to display
    } catch (err) {
        console.error(err);
        res.status(500).send('Error fetching posts');
    }
});

app.get('/login', (req, res) => {
    res.render(__dirname +'/public/login'); // This assumes 'login.ejs' is in the views directory
  });

  app.get('/contact', (req, res) => {
    res.render(__dirname +'/public/contact'); // This assumes 'login.ejs' is in the views directory
  });

  app.get('/about', (req, res) => {
    res.render(__dirname +'/public/about'); // This assumes 'login.ejs' is in the views directory
  });



// Route for handling login form submission
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Check if the username and password match some predefined values (replace with your authentication logic)
  if (username === 'admin' && password === 'admin') {
    // If matched, redirect to another page (dashboard or any other page)
    res.redirect('/dashboard'); // Change '/dashboard' to the desired redirect URL
  } else {
    // If not matched, display an error
    res.status(401).send('Invalid username or password');
  }
});

// Route for the dashboard or the page to which successful login will redirect
// app.get('/dashboard', (req, res) => {
//     res.render(__dirname +'/public/dashboard');
// });

app.get('/dashboard',async (req, res) => {
    try {
        const posts = await Post.find({});
        
        res.render(__dirname + '/public/dashboard', { posts }); // Render the main.ejs file and pass posts data to display
    } catch (err) {
        console.error(err);
        res.status(500).send('Error fetching posts');
    }
});



// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/yourDatabase', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

const postSchema = new mongoose.Schema({
    title: String,
    content: String,
    imageUrl: String,
});

const Post = mongoose.model('Post', postSchema);

// Use Multer for handling file uploads
const upload = multer({ dest: 'public/uploads/' }); // Specify the destination directory

app.get('/', async (req, res) => {
    try {
        const posts = await Post.find({});
        
        res.render(__dirname + '/public/home', { posts }); // Render the main.ejs file and pass posts data to display
    } catch (err) {
        console.error(err);
        res.status(500).send('Error fetching posts');
    }
});

app.post('/submit', upload.single('image'), async (req, res) => {
    const { title, content } = req.body;
    const imageUrl = req.file ? req.file.filename : null;

    try {
        const newPost = new Post({ title, content, imageUrl });
        await newPost.save();
        res.redirect('/'); // Redirect to the main page after saving the post
    } catch (err) {
        console.error(err);
        res.status(500).send('An error occurred while saving the post.');
    }
});

// Render edit page for a specific post
app.get('/edit/:id', async (req, res) => {
    const postId = req.params.id;
    try {
      const post = await Post.findById(postId);
      if (!post) {
        return res.status(404).send('Post not found');
      }
      res.render(__dirname + '/public/edit', { post });
    } catch (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    }
  });
  

// Update a post
app.post('/update/:id', async (req, res) => {
    const postId = req.params.id;
    try {
      const updatedPost = await Post.findByIdAndUpdate(postId, req.body, { new: true });
      if (!updatedPost) {
        return res.status(404).send('Post not found');
      }
      res.redirect('/dashboard'); // Redirect back to the dashboard after updating
    } catch (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    }
  });

//Delete Post
  // Route to handle deleting a post
app.all('/delete/:id', async (req, res) => {
    const postId = req.params.id;
    try {
      if (req.method === 'GET') {
        // Perform any necessary action for GET request (optional)
        // For example, render a confirmation page before deleting
        const post = await Post.findById(postId);
        if (!post) {
          return res.status(404).send('Post not found');
        }
        return res.render(__dirname +'/public/deleteConfirmation', { post });
      } else if (req.method === 'POST') {
        const deletedPost = await Post.findByIdAndDelete(postId);
        if (!deletedPost) {
          return res.status(404).send('Post not found');
        }
        return res.redirect('/dashboard'); // Redirect back to the dashboard after deleting the post
      }
    } catch (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    }
  });
  


// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
